# Managed ACP runtime contract

Contract major: 1. Protocol: ACP v1, schema-v1.26.0.
The account capability `acp.runtime.v1` identifies this runtime interface.
CLI and desktop version numbers do not need to match.
This contract describes source behavior. It is not a release qualification report.

## Commands and transport

```text
verdictan acp agents list --json
verdictan acp agents inspect --agent codex --json
verdictan acp serve --agent codex --profile kalkidan --desktop-version VERSION
```

Use `--agent-config PATH` to select a configuration file.
The default is `~/.verdictan/acp/PROFILE/agents.json`.
Session records, host identity, and release journals stay under the profile directory.
An alternate configuration path does not change that identity directory.

The server exchanges newline-delimited JSON-RPC on stdin and stdout.
Stdout contains protocol messages only. Diagnostics use stderr.
Numeric and string request IDs remain distinct. Notifications have no responses.
Initialize each connection before other operations. The negotiated protocol version is 1.

The account supervisor retains account credentials.
Local CLI processes use its private authenticated socket or named pipe.
Kalkidan uses `--account-bridge` with inherited descriptors 3 and 4.
Descriptor 3 receives account responses. Descriptor 4 sends account requests.
These private frames never appear in ACP streams.
SSH account operations use the existing authenticated desktop connection.
Neither ACP nor SSH receives the desktop account refresh token.

Account logout stops owned runs and revokes managed runtimes.
It does not log out native subscription accounts or unrelated Verdictan profiles.
Provider terminal authentication uses the selected CLI profile with `--login-only`.
The desktop must advertise terminal authentication only when it provides that workflow.

## Discovery and configuration

The built-in profile IDs are `codex`, `claude`, `opencode`, `grok`, `fx`, `pi`, `muse`, and `antigravity`.
Treat profile IDs as opaque. User configuration can add external ACP profiles.
Codex uses app-server. Claude uses stream-json. OpenCode, Grok, and fx use ACP.
Pi uses native RPC. Muse uses native MSP. Antigravity uses ACP. External ACP agents can negotiate ACP 1 or ACP 2;
the desktop-facing protocol remains ACP 1. Rich ACP 2 updates retain their original
content in `verdictan.dev/acpUpdate` metadata.
Executable resolution occurs on the execution host, including login-shell paths.
Windows npm wrappers resolve to their Node executable and script.

`_verdictan/agents/list` returns configured candidates and cached installation facts without probing.
Unknown account, platform, and protocol readiness requires inspection before execution.
`_verdictan/agents/inspect` reads installation, cached protocol, and account facts without initializing an agent session.
Both return `schemaVersion`, `protocolVersion`, `cliVersion`, and `agents`.
Both order agents by readiness: ready installed agents, enabled installed agents, disabled installed agents, then other candidates.
Agents with the same priority keep their configured order. Command output uses the same order.
Listing uses cached facts. Without an inspection cache, installation remains unknown.
Clients must inspect unknown candidates and select a ready selection before starting work, even for the first agent.
Codex inspection uses its host model cache. A missing cache stays unknown until explicit session setup.
API selections use the account model catalog; subscription selections use native catalogs.
Command JSON uses `schema_version`, `protocol_version`, `cli_version`, and `execution_host`.

Each agent record separates installation, protocol, authentication, routing, platform, and features.
`selections` contains model IDs, access modes, provider connections, and readiness.
Only ready selections can start managed work. Optional audio does not gate text.
An ACP handshake does not establish model-routing compatibility.
External routing supports `opencode-openai-responses`, `grok-chat-completions`,
`fx-openai-chat-completions`, `pi-openai-responses`, `muse-openai-responses`, and
`antigravity-gemini`. Generic profiles can declare
`openai-responses-env`, `openai-chat-completions-env`, or `anthropic-messages-env`
with explicit base URL, key, and model environment mappings. The optional `provider`
selects the account provider catalog. OpenCode 1 and 2 use their own configuration formats.
External profiles currently use API access. Native subscription access is not silently converted to API billing.

`_verdictan/config/get` returns definitions without secret environment values.
`_verdictan/config/set` accepts `agents` and applies changes to new connections.
`_verdictan/config/add` accepts one `agent` and merges it under the settings lock.
`_verdictan/agents/registry` reads the official ACP Registry and accepts an optional `query`.
`_verdictan/agents/install` accepts `agentId`, optional `profileId`, `distribution`, and `routing`.
Installation runs on the selected execution host. Binary, npm, and uv distributions
use private installation directories. Profiles without a managed route remain unavailable.
Cursor CLI has no confirmed managed route. It remains unavailable under mandatory governance.
Antigravity requires ACP 1.3.0 or later and its sibling native harness.
Its private HTTPS Gemini endpoint forwards inference through the managed gateway.
Muse uses the endpoint configuration shown in the vendor SDK example.
Its model catalog exposes the selected model; Responses requests use the managed gateway.
Muse exposes native reasoning controls, steering, compaction, approvals, questions, and child-task updates.
Native model changes remain subject to the managed session binding.
Saved configuration applies after session resume.
Native Linux probes exercise both binaries through their endpoint adapters and inference guard with simulated providers.
Muse disables its inner shell sandbox because Verdictan already isolates the complete process tree.
Its native permission prompts remain enabled.
These probes do not establish authenticated control-plane or live provider qualification.
See the [qualification evidence](../../ci/native-agent-probe/evidence/managed-agents-linux-2026-11-02.json) for results and failures.
The Muse example does not establish a vendor support guarantee.
See [Antigravity gateway configuration](https://docs.cloud.google.com/gemini/enterprise/docs/ai-developer-tools/connect-enterprise-gateway)
and the [Muse SDK example](https://meta-models.github.io/muse-code-sdk/next/generated/examples/quickstart-journey/).
Omitting an existing environment preserves its stored values.
`_verdictan/config/import` imports legacy executable preferences and host identity once.
Existing CLI settings take precedence. Reopen the connection after a successful import.

## Sessions and managed selection

Use standard session methods for creation, load, resume, listing, deletion, and close.
Load replays saved updates. Resume restores without replay.
Close releases active execution but preserves history. Delete removes backend state and tombstones history.
One OS-backed lease owns each writable session across processes.
A managed session retains its agent process between successful turns. Configuration changes,
credential expiry, policy refusal, cancellation, and process exit require a new process.
Background tasks can continue while the retained process and its managed credential remain active.
`_verdictan/session/fork` accepts the source `sessionId`, target `cwd`, and session setup fields.
It copies the managed home and asks a backend with fork capability to create native history.
The source must have no foreground turn. The target receives a separate managed binding.
Native history predating ACP remains read-only in Kalkidan.

Session setup accepts these `_meta` entries:

- `verdictan.dev/selection`: explicit managed selection with snake_case account fields.
- `verdictan.dev/choices`: saved desktop choices resolved by the CLI.
- `verdictan.dev/model`: selected model ID.
- `verdictan.dev/access`: selected `model`, `provider_access_mode`, and optional `provider_connection_id`.
- `verdictan.dev/executionHost`: desktop host reference.
- `verdictan.dev/scope`: `project_id` and `task_id` attribution.
- `verdictan.dev/memory`: managed project Memory configuration.
- `verdictan.dev/mcpAllowed`: names of the MCP servers that the agent can start.

`_verdictan/agents/provision` provisions the selected computer resource through the account supervisor.
`_verdictan/session/list` lists owned sessions across profiles, with opaque pagination cursors.
`_verdictan/session/transcript` returns saved updates, profile, roots, title, and timestamps.
`_verdictan/session/evidence` returns binding, execution, evidence, policies, and governance presentation.
All session extensions require `sessionId` and the owning account.

Submitted user chunks retain `verdictan.dev/operationId` in their `_meta` when the caller supplies it.
Replay preserves this ID after success or failure, including turns without tool calls.
Desktop presentation records can use it to restore timing without matching message text.

Ordinary prompts run serially. The desktop owns drafts and queued submissions.
`_verdictan/session/steer` accepts `sessionId` and `prompt` for supported active native turns.
Steering never cancels and resubmits a prompt as a substitute.
Native configuration changes during a turn apply to the next turn.
Responses identify this timing in `verdictan.dev/application` metadata.
Session results and native configuration updates include `verdictan.dev/session` metadata.
It reports model-specific `promptCapabilities` and effective `mcpConfiguration` names, transports, origins, scopes, and execution hosts.
These summaries exclude server credentials and environment values.
External model changes cannot escape the managed model selection.
Native subagent presentation uses `verdictan.dev/subagents` metadata on tool updates.
Child text identifies its parent with `verdictan.dev/parentToolCallId`.
`_verdictan/session/tasks` accepts `sessionId` and returns the live native task list.
`_verdictan/session/stop_task` accepts `sessionId` and `taskId` for retained native sessions and returns the refreshed task list.
Codex terminal task IDs use the `terminal:` prefix; other IDs identify native child tasks.
Claude resolves the visible tool ID to its task ID. Codex interrupts the active child turn.
Kalkidan owns queued drafts on the execution host and pauses them after interruption or failure.
Queue controls are desktop operations, not ACP protocol methods.

## Gateway readiness recovery

Before native execution, readiness HTTP 502, 503, and 504 responses receive at most three attempts.
The waits are one and two seconds. Cancellation stops the wait.
Other errors and invalid readiness evidence fail without retries.
No prompt reaches the native agent until the existing readiness checks pass.
This does not restart the gateway or replay an execution request.

`_verdictan/recovery` reports `schemaVersion: 1`, `sessionId`, `runId`, `phase`, `attempt`, `maxAttempts`, and `at`.
`phase` is `waiting` or `recovered`. Waiting events include `delayMs`.
Timestamps use RFC 3339. Attempts start at one; the limit is three.
Exhaustion returns `desktop.gateway_unavailable`, the HTTP status, `attempts`, and `executionStarted: false`.

## MCP forwarding

Session setup accepts stdio, HTTP, and SSE MCP definitions according to capabilities.
Native configuration scopes are merged with explicit session definitions.
OpenCode JSON and JSONC MCP settings retain user, custom, project, inline, managed-file, and macOS MDM precedence.
Environment and file references resolve on the execution host.
Organization defaults available only through a provider login remain owned by OpenCode.
Explicit ACP definitions can supply servers unavailable to the managed profile.

`verdictan.dev/mcpAllowed` limits the agent to the named servers.
It applies to explicit session definitions and to the agent's own configuration scopes.
The agent does not start a server that is not in the list. An empty list starts no servers.
Without the entry, all servers start.
The managed project Memory server and `verdictan-executor` are not part of this list.
Claude Code starts with `--strict-mcp-config` and only the allowed servers in `--mcp-config`.
Codex gets only the allowed servers in its thread configuration.
Codex and Claude Code use an isolated configuration home, so they read no other MCP servers.
OpenCode still reads project configuration. Its inline configuration disables the servers that are not allowed.
OpenCode managed settings override inline configuration and can still start a server.

`_verdictan/mcp/inherited` lists the servers from the agent's own configuration scopes.
Its params are `cwd` and optional `_meta` with `verdictan.dev/executionHost`.
It returns `servers` with `name`, `transport`, `origin`, `scope`, and `executionHost`.
It does not return commands, URLs, headers, or environment values.
Use it to find the names for `verdictan.dev/mcpAllowed` before session setup.
See [OpenCode configuration](https://opencode.ai/docs/config/) and [MCP configuration](https://opencode.ai/docs/mcp-servers/).
Runtime credential headers remain on their execution host.

Forwarding uses the existing SSH connection to copy opaque MCP JSON-RPC frames:

1. Request `_verdictan/mcp/attach` on the desktop CLI with `role: source`, `server`, and `cwd`.
2. Request the same method on the execution CLI with `role: destination`, `name`, and `scope`.
3. Map each returned `bindingId` to its peer binding.
4. Forward `_verdictan/mcp/message` notifications as `_verdictan/mcp/frame` notifications to the peer.
5. Include the destination's returned `server` in session setup.
6. Detach both bindings when their desktop connection is lost.
7. Close both bindings when their last owning client releases them.

`_verdictan/mcp/detach` disconnects source transports and fails pending calls without replay.
Destination loopback endpoints retain their addresses until close. They return explicit disconnected errors.
`_verdictan/mcp/reconnect` restores source transports and initializes them before destination traffic resumes.
The destination retains its binding ID, loopback address, and credential.
Backend HTTP sessions can reopen without repeating upstream initialization or losing response correlation.
It never replays pending tool calls. Reattach the returned definition during session setup.
`_verdictan/mcp/close` releases the live binding. Registered source definitions remain CLI-owned settings.

`persistentMcp` runtime metadata advertises durable desktop-source references.
`_verdictan/mcp/register` stores `reference`, `host`, `server`, and `cwd` in the local CLI profile.
References contain 64 lowercase hexadecimal characters. Definitions use private files under `mcp-sources`.
Registering a source does not start it. Attach with `role: source`, `reference`, and `host` restores its definition.
The CLI rejects a reference registered for another destination host.
Only the reference crosses SSH; local credentials remain in the desktop CLI profile.

Session listings include `managedAccess` with the saved model, access mode, and provider connection ID.
These values contain no provider credentials. Desktop preferences do not replace saved billing choices.

Session transcripts include `mcpForwarding`, containing only the saved destination placeholders.
Clients retain `kalkidan.desktopMcp` metadata when replacing destination binding IDs.
On session restoration, `verdictan.dev/restoreMcp: true` restores CLI-owned explicit MCP definitions.
Supplied destination placeholders replace saved entries by name. Other saved definitions remain unchanged.
An explicit complete `mcpServers` array without that flag replaces the previous client configuration.
Inherited backend settings are resolved again on the execution host.
`_verdictan/mcp/status` reports connection loss with `replayed: false`.
Destination endpoints are private loopback bridges, not public MCP services.

MCP forwarding does not grant independent model-routing authorization.
Model-calling tools need their own configured managed endpoint.
Verdictan cannot attest model calls made inside a third-party remote MCP service.

## Local action capture

Managed execution writes a separate local journal for complete protocol payloads.
The CLI records native input frames before dispatch and native output bytes before parsing.
Unknown native events, stderr, process errors, exit status, and child-agent events remain in the journal.
ACP requests, results, errors, notifications, and client callbacks retain their complete data.
File callbacks retain the supplied or returned file content.
Terminal callbacks retain the reported command, arguments, output, and exit data.
Model HTTP requests and responses retain headers and all observed body chunks.
Provider HTTP capture retains the mapped request and response chunks before output policy or redaction.
The same recorder covers retry, fallback, quality, embedding, and shadow evaluation requests.
Provider transport capture retains the generated multipart boundary and complete encoded MIME bytes.
It records effective request headers, every redirect response body, and response trailers before following the redirect.
Remote MCP HTTP capture retains malformed bodies and error payloads before SDK decoding.
SDK-discarded HTTP bodies continue through capture under their original lifetime.
Explicit provider close and transport cancellation stop the upstream connection and record incomplete output when EOF was not received.
Gateway WebSocket capture retains inbound and outbound messages and connection events.
Handshake records retain generated request headers, upgrade headers, and rejected upgrade bodies.
The generated server upgrade response starts capture before transmission, but its synchronous hook cannot await disk synchronization.
MCP capture retains complete JSON-RPC messages, including resources, sampling, elicitation, and tool results.
Stdio MCP servers use a captured private bridge instead of an unobserved native transport.
Their subprocesses retain the managed platform isolation, workspace roots, and permitted loopback routes.
Gemini and Muse adapters retain their native exchange as well as the normalized inference exchange.
Gateway command and SDK adapter processes retain launch data, stdin, stdout, stderr, and exit events.
Process output capture occurs before response-size limits or parsing. It drains received output during process cleanup.
Configured execution limits still stop the original operation and produce the corresponding terminal record.

### Owned execution

Every managed session starts a private `verdictan-executor` MCP endpoint on its execution host.
Its reserved name cannot be replaced by a configured server.
The existing session account and mode authorize each action. Native MCP approval flows remain in place.
The endpoint closes with its managed runtime and cancels active child processes before releasing isolation resources.

| Tool | Captured operation |
| --- | --- |
| `execute` | Structured `argv`, working directory, declared environment, stdin, complete stdout and stderr, exit status, and workspace boundary snapshots |
| `read_file` | Complete file bytes, followed by a requested page with readable UTF-8 text and exact base64 data |
| `write_file` | UTF-8 or base64 input and complete before/after file bytes |
| `view_image` | Complete PNG, JPEG, GIF, or WebP bytes and returned image content |
| `list_directory` | Complete directory listing and paged tool output |
| `remove` | Complete before-state, including directory descendants, and the resulting absence |
| `mkdir` | Directory before/after state |
| `spawn_agent` | Delegation input, captured child session, parent/action identity, result, and cancellation |
| `output` | Exact byte pages of stdout, stderr, or a large action result |
| `task_status` | Current or final state of an owned background command |
| `wait_task` | Completion of an owned background command, without cancelling it when the wait ends |
| `stop_task` | Cancellation, termination, and reaping of an owned background command |

File and output pages have a maximum of 32768 bytes. This limits the model response, not the journal.
Command previews identify their complete output through `output` and the action ID.
`execute` accepts `background: true` and returns after isolated launch and capture setup finish.
Background stdout and stderr continue into the journal and output spool after that response.
Background completion records its result, workspace after-state, and terminal task state.
Task controls bypass the action queue, so a wait cannot prevent cancellation.
Parallel `spawn_agent` calls use independent child sessions.
Temporary output pages remain available while the executor is active. Durable journal chunks remain after it closes.
Direct file operations stay within the managed workspace roots and do not follow final symlinks.
Commands run through the existing platform isolation with the session's original edit mode.
Plan mode denies direct edit tools and keeps command workspaces read-only.

Command snapshots include ignored and untracked ordinary files and retain full binary content.
Snapshot records explicitly exclude Verdictan's capture storage and private output spool.
Snapshots describe observed before/after state. They do not identify every intermediate operation or prove attribution against external writers.

Native Codex and Claude have read-only workspace access, while the owned executor performs their file changes.
Codex disables native command execution and shell snapshots. Native image reads remain outside the owned executor.
Model metadata can still expose native patch tools. Read-only workspace access prevents their direct workspace edits.
Claude retains question, planning, and remote web built-ins, disables implicit file mentions, and uses `spawn_agent` for delegation.
Remote web results retain their existing provider boundary; their service internals are not attested.
Owned children receive the same profile, selection, workspace roots, mode, and captured executor.
Their sessions remain readable through the existing session and action APIs.
Successful owned child sessions retain their process, executor, and writable-session lease until parent cleanup.
Their background commands continue to record output across parent turns.
Task listing and stopping include active owned children and background commands, including descendant sessions.
External ACP agents receive the executor alongside their configured tools; their native tool behavior remains agent-defined.
Session evidence and capture results expose the actual executor scope under `executor`.

Configured local stdio MCP servers receive workspace snapshots before `tools/call` dispatch and before result delivery.
The records correlate the server, bridge request, and observed file changes.
Calls without a returned result receive an incomplete record and a shutdown snapshot after the server closes.
These observations do not attest intermediate operations or exclusive attribution.

The [Claude CLI reference](https://code.claude.com/docs/en/cli-reference) defines built-in tool selection.
The [OpenAI configuration reference](https://learn.chatgpt.com/docs/config-file/config-reference) defines command and snapshot feature controls.
The pinned [Codex tool registry](https://raw.githubusercontent.com/openai/codex/d7de4dd3ac3e4c489368c3985013e78622496962/codex-rs/tools/src/tool_registry_plan.rs) still registers native image access and model-selected patch tools.

### Journal storage and reads

Each journal entry has `schemaVersion`, `sessionId`, `streamId`, `sequence`, `timestampNs`, `scope`, `source`, `event`, `payload`, and `cursor`.
The scope retains available account, profile, runtime, and run identifiers.
Binary chunks use base64 and preserve their byte order.
The CLI writes each record once and synchronizes it before forwarding through asynchronous boundaries.
The synchronous WebSocket server upgrade hook has the ordering limit described above.
New journal directories synchronize their parent entries on POSIX systems. Windows record renames use write-through.
Capture errors stop the affected forwarding or execution path.
Completed capture records do not depend on operational telemetry delivery or sampling.

ACP journals are in `~/.verdictan/acp/<profile>/actions/<sessionId>/`.
Gateway journals are in `$VERDICTAN_DATA_DIR/actions/<captureId>/`, or `~/.verdictan/data/actions/<captureId>/` when unset.
Local raw capture is always enabled on the production managed and gateway paths.
It does not inherit History redaction, metadata-only capture, or retention settings.
Headers and payloads can contain credentials and other sensitive content.
Rewind and session deletion do not remove these records. No automatic expiry applies.

`_verdictan/session/actions` requires the owning account and `sessionId`.
It accepts optional `cursor` and `limit` fields. The default limit is 100; the maximum is 1000.
The result has `schemaVersion`, `sessionId`, `records`, `cursor`, `hasMore`, and `replayExecutesRequests: false`.
When another page exists, `nextCursor` identifies the next read position.
The result also describes capture scope under `capture`.
The `journal` object reports the current writer state and its first write error, if any.
Saved records remain readable after a writer failure. The failed writer still stops affected execution.
`_verdictan/mcp/actions` reads forwarding records for the current account and ACP connection, with the same paging fields.
Readers never dispatch recorded actions.

This is raw boundary capture, not attestation of every operation inside an agent or service.
An agent can omit tool events or truncate output before Verdictan receives it.
Unreported native operations and intermediate command effects require instrumentation in their actual executors.
A workspace snapshot establishes a saved state, not every intermediate action.
Remote MCP results do not expose the service's internal model calls, network calls, or file operations.
Runtime metadata reports `internalOsActionsAttested: false` and `remoteServiceInternalsAttested: false`.
Discovery, session evidence, action pages, and gateway desktop readiness report `state: incomplete` and locally derived limits.
The report includes `source: verdictan_cli`, `completenessAttested: false`, recorded boundaries, and limitations.
`fullInputsAndOutputs` applies only to those recorded boundaries.
Gateway desktop readiness exposes this report under `action_capture` and identifies whether a recorder is installed.
Gateway HTTP responses through the application report `x-verdictan-action-capture: incomplete` when capture is installed.
Unsupported integrations remain available. Capture scope does not change readiness or authorize dispatch.
Missing evidence must not be presented as complete capture.

The [ACP tool-call contract](https://agentclientprotocol.com/protocol/v1/tool-calls) makes raw input and output optional.
The [Claude hooks reference](https://code.claude.com/docs/en/hooks) describes tool-hook coverage and output limits.
The [MCP tool specification](https://modelcontextprotocol.io/specification/2025-11-25/server/tools) defines the remote request/result boundary.
Full capture inside a remote service requires instrumentation on that service.

## Evidence and lifecycle

`_verdictan/evidence` carries independent evidence updates and a presentation projection.
`_verdictan/policy` carries gateway policy records.
These extensions are distinct from standard ACP usage updates.
Subscription usage retains token accounting without invented API charges.

`_verdictan/rate_limits` carries subscription limit windows from native Codex and Claude sessions.
The runtime sends it when the agent reports limit data and when a limit error ends a turn.
Its params are `{ sessionId, agent, plan?, windows, updatedAt }`.
`agent` is `codex` or `claude`. `updatedAt` and each `resetsAt` use RFC 3339 UTC.
Each window has `id`, `label`, and optional `usedPercent` (0 to 100), `windowMinutes`,
`resetsAt`, and `status` (`ok`, `warning`, or `reached`).
Each notification contains all windows known for the session. Merge windows by `id`.
Codex windows use `five_hour`, `weekly`, `primary`, or `secondary`.
Codex limits other than `codex` prefix the id with the limit id, for example `<limitId>/weekly`.
Claude windows use `five_hour`, `weekly`, `weekly_opus`, `weekly_sonnet`,
`weekly_overage_included`, `overage`, or `subscription`.
Limit errors without a known window use `usage_limit`, `rate_limit`, or `subscription`.
A limit error keeps the agent's message. Its `data` has `reason: "rate_limit"`, `agent`,
and `resetsAt` with `retryAfterSeconds` when a reset time is known.
Codex errors add `codexErrorInfo` and `additionalDetails`. Claude errors add `rateLimitType`.
Missing evidence remains unavailable rather than becoming a successful policy result.

Transport loss cancels directly attached work. A retained SSH host connection may continue its run.
Each managed process owns an execution credential. New foreground turns update the gateway
attribution. Successful turn completion retains the child and MCP bridges for background work.
Session close, cancellation, failure, logout, or credential expiry closes these resources
and revokes the execution credential.
The ACP owner keeps a gateway service lease for each account, host, agent, and configuration scope.
It renews that lease before expiry. Run credentials do not enter the service lease pool.
Completing a turn does not stop the gateway. Closing the ACP owner stops its gateways after run cleanup.
Logout clears account-bound gateways. A crashed gateway is replaced on the next acquisition.

Connected desktop gateways persist History deliveries before sending them. A delivery first ensures
its correlated session, then writes its entry. Retries reuse `delivery_id`; the API returns the stored
entry without incrementing counters again. Metadata-only capture removes prompt and response content.
Queued deliveries remain after transport failure or shutdown and retry when the gateway starts again.
Deploy API migration `0083_history_delivery.sql` and the API before releasing this CLI.
Failed revocations remain in an account-scoped journal for later retry.
OS locks prevent recovery from revoking another live CLI process's runtime.

Errors use JSON-RPC error codes plus actionable `data.reason` where available.
Authentication, missing installation, unsupported version, routing configuration, binding mismatch,
policy rejection, and process failure remain distinct conditions.

## Platform baseline

macOS x64 and ARM64 require macOS 13.5, the Node 24 baseline, and `sandbox-exec`.
Linux x64 and ARM64 require kernel 4.18, glibc 2.28, Bubblewrap, Python 3, and user namespaces.
Linux account storage also requires the existing secure-store integration.
Windows x64 and ARM64 use bundled MXC 1.0.1 and its native assets.
Supported Windows baselines include builds 26100.9550, 26200.9550, and 28000.2804.
Windows packages remain unsigned. No signing credentials are required.
Discovery reports missing prerequisites independently of executable installation.
Desktop minimums must also satisfy its selected Electron version.

## Desktop combination

Kalkidan uses Electron 44. Its macOS 13 baseline is lower than the CLI Node 24 baseline, so both macOS architectures require 13.5.
Windows x64 and ARM64 require the MXC Windows builds listed above; that requirement exceeds Electron’s Windows baseline.
Linux desktop installations must also use a distribution supported by Electron and Chromium, such as Ubuntu 22.04 or Debian 12, with the native desktop libraries.
Headless SSH hosts do not run Electron and use the CLI Linux baseline above.
See [Electron 44](https://www.electronjs.org/blog/electron-44-0) and [Electron platform support](https://github.com/electron/electron/blob/main/README.md#platform-support).

The machine-readable file includes extension request/result definitions under `x-verdictan-methods`, notification payloads under `x-verdictan-notifications`, and reusable metadata in `$defs`.

## Deletion and retained evidence

Deleting a managed chat removes its transcript and backend restoration data.
The tombstone retains execution attribution, policy records, evidence, and pending release information.
`_verdictan/session/evidence` remains available to the owning account for that deleted session.
Deleted sessions remain absent from listings and cannot load or resume.

### Native provider default

When no provider mode or connection is saved, the runtime can select the native subscription route.
The API must advertise that route, and no matching BYOK connection can compete with it.
External ACP profiles do not use this default. Explicit saved choices take precedence.
The runtime still checks native authentication, account permissions, and policy before execution.


## Submitted chat accounting

Unsent drafts remain on the desktop. Submitted provider requests use the authenticated desktop conversation ID.
History groups requests from the same conversation across execution scopes. Each entry keeps its request ID and desktop run correlation.

The Responses, Chat Completions, and Messages routes use the same History writer and durable delivery queue.
The writer applies the configured capture mode, blocked-request setting, and retention period.
Disabled capture remains disabled. Metadata-only capture does not store message bodies.

History retains reported prompt, completion, cache-read, cache-write, and reasoning token counts.
Cache and reasoning counts are details of the reported totals. Consumers must not add them to those totals again.
Interrupted Messages streams retain available counts with `usage_incomplete: true` and a completion reason.
Missing final provider usage is not proof of zero usage. Financial settlement remains a separate, authorized operation.

Console History displays these fields and the conversation, run, host, and project identifiers.
Retries use the durable delivery identifier. They must not create another entry or increment session counters again.
Historical usage that was never reported cannot be reconstructed as an exact measurement.

External ACP profiles can set `authMethod` to a documented agent authentication method. The runtime invokes it after initialization with the managed environment already installed. Profile environment settings and version arguments are editable on the execution host.

Codex, Claude, and Pi sessions expose history checkpoints through `_verdictan/session/checkpoints`. `_verdictan/session/rewind` accepts a checkpoint ID and both expected current coordinates, retains history through that checkpoint, and stops the retained process. Codex uses `thread/revert`; Claude records a native message cursor for its next resume. Pi forks its native history before the next user entry and binds the returned session file. A fork retains its initial history when rewound to its start. Undo requires current conversation and workspace coordinates. Supported Git workspaces restore the saved files and native conversation checkpoint.

Profile updates accept `environmentUpdates`: string values set individual environment entries and null removes them. Reads return names only; omitted entries remain unchanged.

Other ACP agents use `rewindMode: replay`: the runtime replaces the native session and supplies retained conversation messages and tool results as context with the next prompt. This does not preserve opaque native state. The desktop labels this operation as rebuilding from a checkpoint.

## Operation receipts and work lifecycle

Every submitted operation has an identity and a durable receipt before native dispatch.
Receipt states are `accepted`, `executing`, `completed`, and `unknown`.
Clients supply `verdictan.dev/operationId` and retain it until they receive the result.
Without this ID, identical prompt and execution settings share an implicit operation identity.
Supply a new explicit ID to intentionally repeat the same request.
A repeated completed operation returns its stored result. An uncertain operation never runs again automatically.
These receipts do not guarantee exactly-once effects in external systems.

`_verdictan/session/operation` reads one receipt by `sessionId` and `operationId`.
`_verdictan/session/lifecycle` returns the session, runs, tasks, receipts, recovery, and objective state.
Each task has its own `id`, originating `runId`, `nativeId`, optional parent, kind, and state.
`_verdictan/session/task` publishes durable task changes.
Accepted work has not necessarily started. Executing work has not necessarily completed.
A response can finish while `workState` remains `executing`, `waiting`, or `unknown`.
The objective remains `unconfirmed`; native completion does not establish user objective completion.
Task state lost across a restart becomes unknown until native evidence resolves it.

Native callback dispatch carries a runtime-owned caller session, profile, run, roots, selection, and permission mode.
The runtime checks the owning account before dispatch and after approval.
Native approval option IDs remain unchanged. Child requests use the same governed permission path.

Recovery metadata distinguishes `new_session`, `native_resume`, `native_fork`, and `portable_handoff`.
Portable handoff transfers selected context into a new session. It does not claim native restoration.

## Coordinated undo

Checkpoint listings return current `conversationCoordinate` and `workspaceCoordinate` values.
Each checkpoint also records its target coordinates.
Rewind requires the current values as `expectedConversationCoordinate` and `expectedWorkspaceCoordinate`.
It refuses concurrent session mutation, active or uncertain tasks, changed roots, and changed Git revisions.
Runtime workers share workspace leases on the execution host, including across profiles.
Worktrees have separate workspace leases.

Snapshots include tracked files and non-ignored untracked files. They exclude ignored files and Git metadata.
Submodules and unsupported file types leave workspace undo unavailable. Normal prompts remain available.
Rewind compares current files before replacement. External programs do not participate in runtime leases;
these checks do not provide an atomic transaction across arbitrary external filesystem writers.
A partial undo retains its pending record and blocks new prompts until recovery completes.
Operation receipts survive undo so it cannot silently repeat an earlier action.
