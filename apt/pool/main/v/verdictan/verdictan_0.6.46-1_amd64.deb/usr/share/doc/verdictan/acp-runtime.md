# Managed ACP runtime contract

Contract major: 1. Protocol: ACP v1, schema-v1.26.0.
The account capability `acp.runtime.v1` identifies this runtime interface.
CLI and desktop version numbers do not need to match.
This contract describes source behavior. It is not a release qualification report.

## Commands and transport

```text
verdictan acp agents list --json
verdictan acp agents inspect --agent codex --json
verdictan acp serve --agent codex --profile kalkidan --desktop-version VERSION
```

Use `--agent-config PATH` to select a configuration file.
The default is `~/.verdictan/acp/PROFILE/agents.json`.
Session records, host identity, and release journals stay under the profile directory.
An alternate configuration path does not change that identity directory.

The server exchanges newline-delimited JSON-RPC on stdin and stdout.
Stdout contains protocol messages only. Diagnostics use stderr.
Numeric and string request IDs remain distinct. Notifications have no responses.
Initialize each connection before other operations. The negotiated protocol version is 1.

The runtime runs in local mode. It uses no Verdictan account and sends no request to Verdictan.
The installation identity in `host.json` owns every session, as `local:<installation_id>`.
Each process runs a local gateway on `127.0.0.1` with the built-in default Kalkidan configuration.
Codex and Claude Code use `codex_subscription` and `claude_subscription`.
External ACP agents use `byok` with the user's own provider key from the environment.
A session that an account owned moves to the local account when the CLI loads it.

Logout stops owned runs and the local gateways.
It does not log out native subscription accounts.
Provider terminal authentication uses the selected CLI profile with `--login-only`.
The desktop must advertise terminal authentication only when it provides that workflow.

## Discovery and configuration

The built-in profile IDs are `codex`, `claude`, `opencode`, `grok`, `fx`, `pi`, `muse`, and `antigravity`.
Treat profile IDs as opaque. User configuration can add external ACP profiles.
Codex uses app-server. Claude uses stream-json. OpenCode, Grok, and fx use ACP.
Pi uses native RPC. Muse uses native MSP. Antigravity uses ACP. External ACP agents can negotiate ACP 1 or ACP 2;
the desktop-facing protocol remains ACP 1. Rich ACP 2 updates retain their original
content in `verdictan.dev/acpUpdate` metadata.
Executable resolution occurs on the execution host, including login-shell paths.
Windows npm wrappers resolve to their Node executable and script.

`_verdictan/agents/list` returns configured candidates and cached installation facts without probing.
Unknown account, platform, and protocol readiness requires inspection before execution.
`_verdictan/agents/inspect` reads installation, cached protocol, and account facts without initializing an agent session.
Both return `schemaVersion`, `protocolVersion`, `cliVersion`, and `agents`.
Both order agents by readiness: ready installed agents, enabled installed agents, disabled installed agents, then other candidates.
Agents with the same priority keep their configured order. Command output uses the same order.
Listing uses cached facts. Without an inspection cache, installation remains unknown.
Clients must inspect unknown candidates and select a ready selection before starting work, even for the first agent.
Codex inspection uses its host model cache. A missing cache stays unknown until explicit session setup.
Subscription selections use native catalogs. The first selection of an agent is its default model.
Command JSON uses `schema_version`, `protocol_version`, `cli_version`, and `execution_host`.

Each agent record separates installation, protocol, authentication, routing, platform, and features.
`selections` contains model IDs, access modes, provider connections, and readiness.
Only ready selections can start managed work. Optional audio does not gate text.
An ACP handshake does not establish model-routing compatibility.
External routing supports `opencode-openai-responses`, `grok-chat-completions`,
`fx-openai-chat-completions`, `pi-openai-responses`, `muse-openai-responses`, and
`antigravity-gemini`. Generic profiles can declare
`openai-responses-env`, `openai-chat-completions-env`, or `anthropic-messages-env`
with explicit base URL, key, and model environment mappings. The optional `provider`
selects the account provider catalog. OpenCode 1 and 2 use their own configuration formats.
External profiles currently use API access. Native subscription access is not silently converted to API billing.

`_verdictan/config/get` returns definitions without secret environment values.
`_verdictan/config/set` accepts `agents` and applies changes to new connections.
`_verdictan/config/add` accepts one `agent` and merges it under the settings lock.
`_verdictan/agents/registry` reads the official ACP Registry and accepts an optional `query`.
`_verdictan/agents/install` accepts `agentId`, optional `profileId`, `distribution`, and `routing`.
Installation runs on the selected execution host. Binary, npm, and uv distributions
use private installation directories. Profiles without a managed route remain unavailable.
Cursor CLI has no confirmed managed route. It remains unavailable under mandatory governance.
Antigravity requires ACP 1.3.0 or later and its sibling native harness.
Its private HTTPS Gemini endpoint forwards inference through the managed gateway.
Muse uses the endpoint configuration shown in the vendor SDK example.
Its model catalog exposes the selected model; Responses requests use the managed gateway.
Muse exposes native reasoning controls, steering, compaction, approvals, questions, and child-task updates.
Native model changes remain subject to the managed session binding.
Saved configuration applies after session resume.
Native Linux probes exercise both binaries through their endpoint adapters and inference guard with simulated providers.
Muse disables its inner shell sandbox because Verdictan already isolates the complete process tree.
Its native permission prompts remain enabled.
These probes do not establish authenticated control-plane or live provider qualification.
See the [qualification evidence](../../ci/native-agent-probe/evidence/managed-agents-linux-2026-11-02.json) for results and failures.
The Muse example does not establish a vendor support guarantee.
See [Antigravity gateway configuration](https://docs.cloud.google.com/gemini/enterprise/docs/ai-developer-tools/connect-enterprise-gateway)
and the [Muse SDK example](https://meta-models.github.io/muse-code-sdk/next/generated/examples/quickstart-journey/).
Omitting an existing environment preserves its stored values.
`_verdictan/config/import` imports legacy executable preferences and host identity once.
Existing CLI settings take precedence. Reopen the connection after a successful import.

## Sessions and managed selection

Use standard session methods for creation, load, resume, listing, deletion, and close.
Load replays saved updates. Resume restores without replay.
Close releases active execution but preserves history. Delete removes backend state and tombstones history.
One OS-backed lease owns each writable session across processes.
A managed session retains its agent process between successful turns. Configuration changes,
credential expiry, policy refusal, cancellation, and process exit require a new process.
Background tasks can continue while the retained process and its managed credential remain active.
`_verdictan/session/fork` accepts the source `sessionId`, target `cwd`, and session setup fields.
It copies the managed home and asks a backend with fork capability to create native history.
The source must have no foreground turn. The target receives a separate managed binding.
Native history predating ACP remains read-only in Kalkidan.

Session setup accepts these `_meta` entries:

- `verdictan.dev/model`: selected model ID.
- `verdictan.dev/access`: selected `model`, `provider_access_mode`, and optional `provider_connection_id`.
- `verdictan.dev/executionHost`: desktop host reference.
- `verdictan.dev/scope`: `project_id` and `task_id` attribution.
- `verdictan.dev/memory`: managed project Memory configuration.
- `verdictan.dev/mcpAllowed`: names of the MCP servers that the agent can start.
- `verdictan.dev/localContent`: local content mark for the session. See "Local content".

`_verdictan/agents/provision` starts the local gateway. It creates no remote resource.
`_verdictan/session/list` lists owned sessions across profiles, with opaque pagination cursors.
`_verdictan/session/transcript` returns saved updates, profile, roots, title, and timestamps.
`_verdictan/session/evidence` returns binding, execution, evidence, policies, and governance presentation.
All session extensions require `sessionId` and the owning account.

Submitted user chunks retain `verdictan.dev/operationId` in their `_meta` when the caller supplies it.
Replay preserves this ID after success or failure, including turns without tool calls.
Desktop presentation records can use it to restore timing without matching message text.

Ordinary prompts run serially. The desktop owns drafts and queued submissions.
`_verdictan/session/steer` accepts `sessionId` and `prompt` for supported active native turns.
Steering never cancels and resubmits a prompt as a substitute.
Native configuration changes during a turn apply to the next turn.
Responses identify this timing in `verdictan.dev/application` metadata.
Session results and native configuration updates include `verdictan.dev/session` metadata.
It reports model-specific `promptCapabilities` and effective `mcpConfiguration` names, transports, origins, scopes, and execution hosts.
These summaries exclude server credentials and environment values.
External model changes cannot escape the managed model selection.
Native subagent presentation uses `verdictan.dev/subagents` metadata on tool updates.
Child text identifies its parent with `verdictan.dev/parentToolCallId`.
`_verdictan/session/tasks` accepts `sessionId` and returns the live native task list.
`_verdictan/session/stop_task` accepts `sessionId` and `taskId` for retained native sessions and returns the refreshed task list.
Codex terminal task IDs use the `terminal:` prefix; other IDs identify native child tasks.
Claude resolves the visible tool ID to its task ID. Codex interrupts the active child turn.
Kalkidan owns queued drafts on the execution host and pauses them after interruption or failure.
Queue controls are desktop operations, not ACP protocol methods.

## Gateway readiness recovery

Before native execution, readiness HTTP 502, 503, and 504 responses receive at most three attempts.
The waits are one and two seconds. Cancellation stops the wait.
Other errors and invalid readiness evidence fail without retries.
No prompt reaches the native agent until the existing readiness checks pass.
This does not restart the gateway or replay an execution request.

`_verdictan/recovery` reports `schemaVersion: 1`, `sessionId`, `runId`, `phase`, `attempt`, `maxAttempts`, and `at`.
`phase` is `waiting` or `recovered`. Waiting events include `delayMs`.
Timestamps use RFC 3339. Attempts start at one; the limit is three.
Exhaustion returns `desktop.gateway_unavailable`, the HTTP status, `attempts`, and `executionStarted: false`.

## MCP forwarding

Session setup accepts stdio, HTTP, and SSE MCP definitions according to capabilities.
Native configuration scopes are merged with explicit session definitions.
OpenCode JSON and JSONC MCP settings retain user, custom, project, inline, managed-file, and macOS MDM precedence.
Environment and file references resolve on the execution host.
Organization defaults available only through a provider login remain owned by OpenCode.
Explicit ACP definitions can supply servers unavailable to the managed profile.

`verdictan.dev/mcpAllowed` limits the agent to the named servers.
It applies to explicit session definitions and to the agent's own configuration scopes.
The agent does not start a server that is not in the list. An empty list starts no servers.
A session keeps its list on resume, fork, and owned child-agent creation, until the client sends another list.
Without a list, all servers start, and no account connector starts.
The managed project Memory server and `verdictan-executor` are not part of this list.
Claude Code starts with `--strict-mcp-config` and only the allowed servers in `--mcp-config`.
Codex gets only the allowed servers in its thread configuration.
Codex and Claude Code use an isolated configuration home, so they read no other MCP servers.
OpenCode still reads project configuration. Its inline configuration disables the servers that are not allowed.
OpenCode managed settings override inline configuration and can still start a server.

`_verdictan/mcp/inherited` lists the servers from the agent's own configuration scopes.
Its params are `cwd` and optional `_meta` with `verdictan.dev/executionHost`.
It returns `servers` with `name`, `transport`, `origin`, `scope`, and `executionHost`.
It does not return commands, URLs, headers, or environment values.
It also lists the account connectors, with `scope: "account"`. See "Account connectors".
Use it to find the names for `verdictan.dev/mcpAllowed` before session setup.
See [OpenCode configuration](https://opencode.ai/docs/config/) and [MCP configuration](https://opencode.ai/docs/mcp-servers/).
Runtime credential headers remain on their execution host.

Forwarding uses the existing SSH connection to copy opaque MCP JSON-RPC frames:

1. Request `_verdictan/mcp/attach` on the desktop CLI with `role: source`, `server`, and `cwd`.
2. Request the same method on the execution CLI with `role: destination`, `name`, and `scope`.
3. Map each returned `bindingId` to its peer binding.
4. Forward `_verdictan/mcp/message` notifications as `_verdictan/mcp/frame` notifications to the peer.
5. Include the destination's returned `server` in session setup.
6. Detach both bindings when their desktop connection is lost.
7. Close both bindings when their last owning client releases them.

`_verdictan/mcp/detach` disconnects source transports and fails pending calls without replay.
Destination loopback endpoints retain their addresses until close. They return explicit disconnected errors.
`_verdictan/mcp/reconnect` restores source transports and initializes them before destination traffic resumes.
The destination retains its binding ID, loopback address, and credential.
Backend HTTP sessions can reopen without repeating upstream initialization or losing response correlation.
It never replays pending tool calls. Reattach the returned definition during session setup.
`_verdictan/mcp/close` releases the live binding. Registered source definitions remain CLI-owned settings.

`persistentMcp` runtime metadata advertises durable desktop-source references.
`_verdictan/mcp/register` stores `reference`, `host`, `server`, and `cwd` in the local CLI profile.
References contain 64 lowercase hexadecimal characters. Definitions use private files under `mcp-sources`.
Registering a source does not start it. Attach with `role: source`, `reference`, and `host` restores its definition.
The CLI rejects a reference registered for another destination host.
Only the reference crosses SSH; local credentials remain in the desktop CLI profile.

Session listings include `managedAccess` with the saved model, access mode, and provider connection ID.
These values contain no provider credentials. Desktop preferences do not replace saved billing choices.

Session transcripts include `mcpForwarding`, containing only the saved destination placeholders.
Clients retain `kalkidan.desktopMcp` metadata when replacing destination binding IDs.
On session restoration, `verdictan.dev/restoreMcp: true` restores CLI-owned explicit MCP definitions.
Supplied destination placeholders replace saved entries by name. Other saved definitions remain unchanged.
An explicit complete `mcpServers` array without that flag replaces the previous client configuration.
Inherited backend settings are resolved again on the execution host.
`_verdictan/mcp/status` reports connection loss with `replayed: false`.
Destination endpoints are private loopback bridges, not public MCP services.

MCP forwarding does not grant independent model-routing authorization.
Model-calling tools need their own configured managed endpoint.
Verdictan cannot attest model calls made inside a third-party remote MCP service.

## Session filesystem exclusions

On macOS, `filesystemExclusions: true` advertises enforced session path exclusions.
Clients pass absolute paths in `_meta["verdictan.dev/excludedPaths"]` when opening a session.
The runtime persists these paths and retains them on resume, fork, and owned child-agent creation.
Later requests can add exclusions but cannot remove existing exclusions from a session.
Other execution platforms reject nonempty exclusions until their isolation supports them.

Excluded directories and their descendants cannot be read or changed by native agents, executor commands, or session MCP processes.
MCP forwarding sources are not session processes and do not receive session exclusions.
A session that has stored exclusions does not open on a runtime without the capability.
The owned file tools and workspace capture skip excluded paths, including canonical symlink targets.
Checkpoint restoration refuses excluded paths.
Exclusions do not filter text that a person explicitly submits in a prompt.
Clients must require the advertised capability before submitting protected work.

## Local action capture

Managed execution writes a separate local journal for complete protocol payloads.
The CLI records native input frames before dispatch and native output bytes before parsing.
Unknown native events, stderr, process errors, exit status, and child-agent events remain in the journal.
ACP requests, results, errors, notifications, and client callbacks retain their complete data.
File callbacks retain the supplied or returned file content.
Terminal callbacks retain the reported command, arguments, output, and exit data.
Model HTTP requests and responses retain headers and all observed body chunks.
Provider HTTP capture retains the mapped request and response chunks before output policy or redaction.
The same recorder covers retry, fallback, quality, embedding, and shadow evaluation requests.
Provider transport capture retains the generated multipart boundary and complete encoded MIME bytes.
It records effective request headers, every redirect response body, and response trailers before following the redirect.
Remote MCP HTTP capture retains malformed bodies and error payloads before SDK decoding.
SDK-discarded HTTP bodies continue through capture under their original lifetime.
Explicit provider close and transport cancellation stop the upstream connection and record incomplete output when EOF was not received.
Gateway WebSocket capture retains inbound and outbound messages and connection events.
Handshake records retain generated request headers, upgrade headers, and rejected upgrade bodies.
The generated server upgrade response starts capture before transmission, but its synchronous hook cannot await disk synchronization.
MCP capture retains complete JSON-RPC messages, including resources, sampling, elicitation, and tool results.
Stdio MCP servers use a captured private bridge instead of an unobserved native transport.
Their subprocesses retain the managed platform isolation, workspace roots, and permitted loopback routes.
Gemini and Muse adapters retain their native exchange as well as the normalized inference exchange.
Gateway command and SDK adapter processes retain launch data, stdin, stdout, stderr, and exit events.
Process output capture occurs before response-size limits or parsing. It drains received output during process cleanup.
Configured execution limits still stop the original operation and produce the corresponding terminal record.

### Owned execution

Every managed session starts a private `verdictan-executor` MCP endpoint on its execution host.
Its reserved name cannot be replaced by a configured server.
The existing session account and mode authorize each action. Native MCP approval flows remain in place.
The endpoint closes with its managed runtime and cancels active child processes before releasing isolation resources.

| Tool | Captured operation |
| --- | --- |
| `execute` | Structured `argv`, working directory, declared environment, stdin, complete stdout and stderr, exit status, and workspace boundary snapshots |
| `read_file` | Complete file bytes, followed by a requested page with readable UTF-8 text and exact base64 data |
| `write_file` | UTF-8 or base64 input and complete before/after file bytes |
| `view_image` | Complete PNG, JPEG, GIF, or WebP bytes and returned image content |
| `list_directory` | Complete directory listing and paged tool output |
| `remove` | Complete before-state, including directory descendants, and the resulting absence |
| `mkdir` | Directory before/after state |
| `spawn_agent` | Delegation input, captured child session, parent/action identity, result, and cancellation |
| `output` | Exact byte pages of stdout, stderr, or a large action result |
| `task_status` | Current or final state of an owned background command |
| `wait_task` | Completion of an owned background command, without cancelling it when the wait ends |
| `stop_task` | Cancellation, termination, and reaping of an owned background command |

File and output pages have a maximum of 32768 bytes. This limits the model response, not the journal.
Command previews identify their complete output through `output` and the action ID.
`execute` accepts `background: true` and returns after isolated launch and capture setup finish.
Background stdout and stderr continue into the journal and output spool after that response.
Background completion records its result, workspace after-state, and terminal task state.
Task controls bypass the action queue, so a wait cannot prevent cancellation.
Parallel `spawn_agent` calls use independent child sessions.
Temporary output pages remain available while the executor is active. Durable journal chunks remain after it closes.
Direct file operations stay within the managed workspace roots and do not follow final symlinks.
Commands run through the existing platform isolation with the session's original edit mode.
Command arguments grant no path. Only the program, the workspace roots, and runtime folders are granted.
Plan mode denies direct edit tools and keeps command workspaces read-only.

Command snapshots include untracked files and ignored files, and retain full binary content.
They leave out folders that Git ignores and that have a build output name, for example `node_modules`, `build`, or `dist`.
A `paths` entry with `observed: false` names each such folder. Other ignored folders stay included.
Files below `.git/objects` of a workspace root are named with their metadata, without content.
The first snapshot of a session lists each path. A later snapshot lists only changed paths; `baseline` names the earlier snapshot.
A file with the same size, mode, times, device, and inode, including the inode change time, is not read again.
`contents` records hold each content once, with its `sha256` on the final part. `paths` entries name that digest.
`contentRecordedInSession` names an earlier session of the profile that recorded the content, for any folder or worktree.
Content of a session with local content, or without a journal, is recorded again.
Nothing removes recorded content automatically.
`startedWithCommand: true` marks a first snapshot that ran beside a background command, so it can contain its changes.
A snapshot that cannot finish records `snapshot_interrupted`.
Snapshot records explicitly exclude Verdictan's capture storage and private output spool.
Snapshots describe observed before/after state. They do not identify every intermediate operation or prove attribution against external writers.

Native Codex and Claude have read-only workspace access, while the owned executor performs their file changes.
Codex disables native command execution and shell snapshots. Native image reads remain outside the owned executor.
Model metadata can still expose native patch tools. Read-only workspace access prevents their direct workspace edits.
Claude retains question, planning, and remote web built-ins, disables implicit file mentions, and uses `spawn_agent` for delegation.
Remote web results retain their existing provider boundary; their service internals are not attested.
Owned children receive the same profile, selection, workspace roots, mode, and captured executor.
Their sessions remain readable through the existing session and action APIs.
Successful owned child sessions retain their process, executor, and writable-session lease until parent cleanup.
Their background commands continue to record output across parent turns.
Task listing and stopping include active owned children and background commands, including descendant sessions.
External ACP agents receive the executor alongside their configured tools; their native tool behavior remains agent-defined.
Session evidence and capture results expose the actual executor scope under `executor`.

Configured local stdio MCP servers receive workspace snapshots before `tools/call` dispatch and before result delivery.
The records correlate the server, bridge request, and observed file changes.
Calls without a returned result receive an incomplete record and a shutdown snapshot after the server closes.
These observations do not attest intermediate operations or exclusive attribution.

The [Claude CLI reference](https://code.claude.com/docs/en/cli-reference) defines built-in tool selection.
The [OpenAI configuration reference](https://learn.chatgpt.com/docs/config-file/config-reference) defines command and snapshot feature controls.
The pinned [Codex tool registry](https://raw.githubusercontent.com/openai/codex/d7de4dd3ac3e4c489368c3985013e78622496962/codex-rs/tools/src/tool_registry_plan.rs) still registers native image access and model-selected patch tools.

### Journal storage and reads

Each journal entry has `schemaVersion`, `sessionId`, `streamId`, `sequence`, `timestampNs`, `scope`, `source`, `event`, `payload`, and `cursor`.
The scope retains available account, profile, runtime, and run identifiers.
Binary chunks use base64 and preserve their byte order.
The CLI writes each record once and synchronizes it before forwarding through asynchronous boundaries.
The synchronous WebSocket server upgrade hook has the ordering limit described above.
New journal directories synchronize their parent entries on POSIX systems. Windows record renames use write-through.
Capture errors stop the affected forwarding or execution path.
Completed capture records do not depend on operational telemetry delivery or sampling.

ACP journals are in `~/.verdictan/acp/<profile>/actions/<sessionId>/`.
Gateway journals are in `$VERDICTAN_DATA_DIR/actions/<captureId>/`, or `~/.verdictan/data/actions/<captureId>/` when unset.
Local raw capture is always enabled on the production managed and gateway paths.
It does not inherit History redaction, metadata-only capture, or retention settings.
Headers and payloads can contain credentials and other sensitive content.
Rewind and session deletion do not remove these records. No automatic expiry applies.

`_verdictan/session/actions` requires the owning account and `sessionId`.
It accepts optional `cursor` and `limit` fields. The default limit is 100; the maximum is 1000.
The result has `schemaVersion`, `sessionId`, `records`, `cursor`, `hasMore`, and `replayExecutesRequests: false`.
When another page exists, `nextCursor` identifies the next read position.
A page also ends at 16 MiB, so it can have fewer records than `limit`. Read until `hasMore` is false.
The result also describes capture scope under `capture`.
The `journal` object reports the current writer state and its first write error, if any.
Saved records remain readable after a writer failure. The failed writer still stops affected execution.
`_verdictan/mcp/actions` reads forwarding records for the current account and ACP connection, with the same paging fields.
Readers never dispatch recorded actions.

This is raw boundary capture, not attestation of every operation inside an agent or service.
An agent can omit tool events or truncate output before Verdictan receives it.
Unreported native operations and intermediate command effects require instrumentation in their actual executors.
A workspace snapshot establishes a saved state, not every intermediate action.
Remote MCP results do not expose the service's internal model calls, network calls, or file operations.
Runtime metadata reports `internalOsActionsAttested: false` and `remoteServiceInternalsAttested: false`.
Discovery, session evidence, action pages, and gateway desktop readiness report `state: incomplete` and locally derived limits.
The report includes `source: verdictan_cli`, `completenessAttested: false`, recorded boundaries, and limitations.
`fullInputsAndOutputs` applies only to those recorded boundaries.
Gateway desktop readiness exposes this report under `action_capture` and identifies whether a recorder is installed.
Gateway HTTP responses through the application report `x-verdictan-action-capture: incomplete` when capture is installed.
Unsupported integrations remain available. Capture scope does not change readiness or authorize dispatch.
Missing evidence must not be presented as complete capture.

The [ACP tool-call contract](https://agentclientprotocol.com/protocol/v1/tool-calls) makes raw input and output optional.
The [Claude hooks reference](https://code.claude.com/docs/en/hooks) describes tool-hook coverage and output limits.
The [MCP tool specification](https://modelcontextprotocol.io/specification/2025-11-25/server/tools) defines the remote request/result boundary.
Full capture inside a remote service requires instrumentation on that service.

## Evidence and lifecycle

`_verdictan/evidence` carries independent evidence updates and a presentation projection.
`_verdictan/policy` carries gateway policy records.
These extensions are distinct from standard ACP usage updates.
Subscription usage retains token accounting without invented API charges.

`_verdictan/rate_limits` carries subscription limit windows from native Codex and Claude sessions.
The runtime sends it when the agent reports limit data and when a limit error ends a turn.
Its params are `{ sessionId, agent, plan?, windows, updatedAt }`.
`agent` is `codex` or `claude`. `updatedAt` and each `resetsAt` use RFC 3339 UTC.
Each window has `id`, `label`, and optional `usedPercent` (0 to 100), `windowMinutes`,
`resetsAt`, and `status` (`ok`, `warning`, or `reached`).
Each notification contains all windows known for the session. Merge windows by `id`.
Codex windows use `five_hour`, `weekly`, `primary`, or `secondary`.
Codex limits other than `codex` prefix the id with the limit id, for example `<limitId>/weekly`.
Claude windows use `five_hour`, `weekly`, `weekly_opus`, `weekly_sonnet`,
`weekly_overage_included`, `overage`, or `subscription`.
Limit errors without a known window use `usage_limit`, `rate_limit`, or `subscription`.
A limit error keeps the agent's message. Its `data` has `reason: "rate_limit"`, `agent`,
and `resetsAt` with `retryAfterSeconds` when a reset time is known.
Codex errors add `codexErrorInfo` and `additionalDetails`. Claude errors add `rateLimitType`.
Missing evidence remains unavailable rather than becoming a successful policy result.

Transport loss cancels directly attached work. A retained SSH host connection may continue its run.
Each managed process owns an execution credential. New foreground turns update the gateway
attribution. Successful turn completion retains the child and MCP bridges for background work.
Session close, cancellation, failure, logout, or credential expiry closes these resources
and releases the execution credential.
A model response of the local gateway can take up to one hour.
The ACP owner keeps one local gateway for its owner. Run credentials expire after 24 hours.
Completing a turn does not stop the gateway. Closing the ACP owner stops its gateways after run cleanup.
Logout stops the gateways. A crashed gateway is replaced on the next acquisition.

Connected desktop gateways persist History deliveries before sending them. A delivery first ensures
its correlated session, then writes its entry. Retries reuse `delivery_id`; the API returns the stored
entry without incrementing counters again. Metadata-only capture removes prompt and response content.
Queued deliveries remain after transport failure or shutdown and retry when the gateway starts again.
Deploy API migration `0083_history_delivery.sql` and the API before releasing this CLI.

Errors use JSON-RPC error codes plus actionable `data.reason` where available.
Authentication, missing installation, unsupported version, routing configuration, binding mismatch,
policy rejection, and process failure remain distinct conditions.

## Platform baseline

macOS x64 and ARM64 require macOS 13.5, the Node 24 baseline, and `sandbox-exec`.
Linux x64 and ARM64 require kernel 4.18, glibc 2.28, Bubblewrap, Python 3, and user namespaces.
Linux account storage also requires the existing secure-store integration.
Windows x64 and ARM64 use bundled MXC 1.0.1 and its native assets.
Supported Windows baselines include builds 26100.9550, 26200.9550, and 28000.2804.
Windows packages remain unsigned. No signing credentials are required.
Discovery reports missing prerequisites independently of executable installation.
Kalkidan requires native macOS 26. SSH execution hosts use the CLI baselines above.

## Desktop combination

Kalkidan is a native SwiftUI application for macOS 26.
It connects to Linux and macOS execution hosts over SSH.
Headless execution hosts do not require the desktop application.
Windows runtime support does not establish Kalkidan desktop support.

The machine-readable file includes extension request/result definitions under `x-verdictan-methods`, notification payloads under `x-verdictan-notifications`, and reusable metadata in `$defs`.

## Deletion and retained evidence

Deleting a managed chat removes its transcript and backend restoration data.
The tombstone retains execution attribution, policy records, evidence, and pending release information.
`_verdictan/session/evidence` remains available to the owning account for that deleted session.
Deleted sessions remain absent from listings and cannot load or resume.

### Native provider default

When no provider mode or connection is saved, the runtime can select the native subscription route.
The API must advertise that route, and no matching BYOK connection can compete with it.
External ACP profiles do not use this default. Explicit saved choices take precedence.
The runtime still checks native authentication, account permissions, and policy before execution.


## Submitted chat accounting

Unsent drafts remain on the desktop. Submitted provider requests use the authenticated desktop conversation ID.
History groups requests from the same conversation across execution scopes. Each entry keeps its request ID and desktop run correlation.

The Responses, Chat Completions, and Messages routes use the same History writer and durable delivery queue.
The writer applies the configured capture mode, blocked-request setting, and retention period.
Disabled capture remains disabled. Metadata-only capture does not store message bodies.

History retains reported prompt, completion, cache-read, cache-write, and reasoning token counts.
Cache and reasoning counts are details of the reported totals. Consumers must not add them to those totals again.
Interrupted Messages streams retain available counts with `usage_incomplete: true` and a completion reason.
Missing final provider usage is not proof of zero usage. Financial settlement remains a separate, authorized operation.

Console History displays these fields and the conversation, run, host, and project identifiers.
Retries use the durable delivery identifier. They must not create another entry or increment session counters again.
Historical usage that was never reported cannot be reconstructed as an exact measurement.

External ACP profiles can set `authMethod` to a documented agent authentication method. The runtime invokes it after initialization with the managed environment already installed. Profile environment settings and version arguments are editable on the execution host.

Codex, Claude, and Pi sessions expose history checkpoints through `_verdictan/session/checkpoints`. `_verdictan/session/rewind` accepts a checkpoint ID and both expected current coordinates, retains history through that checkpoint, and stops the retained process. Codex uses `thread/revert`; Claude records a native message cursor for its next resume. Pi forks its native history before the next user entry and binds the returned session file. A fork retains its initial history when rewound to its start. Undo requires current conversation and workspace coordinates. Supported Git workspaces restore the saved files and native conversation checkpoint.

Profile updates accept `environmentUpdates`: string values set individual environment entries and null removes them. Reads return names only; omitted entries remain unchanged.

Other ACP agents use `rewindMode: replay`: the runtime replaces the native session and supplies retained conversation messages and tool results as context with the next prompt. This does not preserve opaque native state. The desktop labels this operation as rebuilding from a checkpoint.

## Operation receipts and work lifecycle

Every submitted operation has an identity and a durable receipt before native dispatch.
Receipt states are `accepted`, `executing`, `completed`, and `unknown`.
Clients supply `verdictan.dev/operationId` and retain it until they receive the result.
Without this ID, identical prompt and execution settings share an implicit operation identity.
Supply a new explicit ID to intentionally repeat the same request.
A repeated completed operation returns its stored result. An uncertain operation never runs again automatically.
These receipts do not guarantee exactly-once effects in external systems.

`_verdictan/session/operation` reads one receipt by `sessionId` and `operationId`.
`_verdictan/session/lifecycle` returns the session, runs, tasks, receipts, recovery, and objective state.
Each task has its own `id`, originating `runId`, `nativeId`, optional parent, kind, and state.
`_verdictan/session/task` publishes durable task changes.
Accepted work has not necessarily started. Executing work has not necessarily completed.
A response can finish while `workState` remains `executing`, `waiting`, or `unknown`.
The objective remains `unconfirmed`; native completion does not establish user objective completion.
Task state lost across a restart becomes unknown until native evidence resolves it.

Native callback dispatch carries a runtime-owned caller session, profile, run, roots, selection, and permission mode.
The runtime checks the owning account before dispatch and after approval.
Native approval option IDs remain unchanged. Child requests use the same governed permission path.

Recovery metadata distinguishes `new_session`, `native_resume`, `native_fork`, and `portable_handoff`.
Portable handoff transfers selected context into a new session. It does not claim native restoration.

## Coordinated undo

Checkpoint listings return current `conversationCoordinate` and `workspaceCoordinate` values.
Each checkpoint also records its target coordinates.
Rewind requires the current values as `expectedConversationCoordinate` and `expectedWorkspaceCoordinate`.
It refuses concurrent session mutation, active or uncertain tasks, changed roots, and changed Git revisions.
Runtime workers share workspace leases on the execution host, including across profiles.
Worktrees have separate workspace leases.

Checkpoints and rewind stay inside the workspace folders, also below a larger repository or in a worktree.
For the top folder of a repository or worktree, snapshots include tracked files and non-ignored untracked files.
For another folder, they include each file except Git metadata and folders with a build output name.
Such a folder has no checkpoint above 5,000 files or 256 MiB.
An earlier checkpoint that covers other folders is refused.
Submodules and unsupported file types leave workspace undo unavailable. Normal prompts remain available.
Rewind compares current files before replacement. External programs do not participate in runtime leases;
these checks do not provide an atomic transaction across arbitrary external filesystem writers.
A partial undo retains its pending record and blocks new prompts until recovery completes.
Operation receipts survive undo so it cannot silently repeat an earlier action.

## Account connectors

`agentCapabilities._meta["verdictan.dev/runtime"].accountConnectors` advertises this section.
The runtime is the client of the connectors in the Claude and ChatGPT accounts of the person.
Agents receive no vendor token and no route to a connector host.
The vendors do not publish these endpoints for other clients, so a vendor change can make a connector unavailable.

`_verdictan/mcp/inherited` lists each connector with `scope: "account"` and these fields:
`name`, `vendor` (`anthropic` or `openai`), `agent` (`claude` or `codex`), `connector`, and `tools`.
Each tool has `name`, `title`, and `readOnlyHint`. `accounts` reports the state of each account and a reason.
The `name` has the agent, the connector, and a part of the connector ID digest, for example `claude-gmail-1a2b3c`.
Treat it as opaque. The runtime keeps the catalog for at most five minutes.

`verdictan.dev/mcpAllowed` starts a connector only by its name. An entry can be `{ "name": ..., "tools": [...] }`.
The agent then sees and can call only those tools. Any agent can use connectors of either account.
The agent cannot widen the list. `verdictan.dev/session` reports `connectors` with their state.
A missing connector does not stop the session; its reason is `account_connector_unavailable`.

Each connector is a loopback MCP server outside the sandbox. The bridge reads the current sign-in for each request.
A tool with `readOnlyHint: true` runs with no question.
Any other tool first sends `session/request_permission` with `toolCall._meta["verdictan.dev/connector"]`:
`callId`, `vendor`, `agent`, `name`, `connector`, `tool`, `title`, and `arguments`.
Plan mode refuses these tools. The bridge sends an allowed call once. A cancelled call is not sent after a late answer.
Native agent approvals for connector tools are accepted, because the bridge asks the person.
When the answer is lost, the result has `outcome: "unknown"` and the `callId`, and the bridge does not send again.
A refused or unavailable call has `account_connector_unavailable` and the reason of the vendor.

`_verdictan/connectors/call` accepts `connector`, `tool`, `arguments`, `operationId`, and `approved`.
A read-only tool runs at once. Any other tool runs only with `approved: true`, else it fails with `reason: "approval_required"`.
A refused request does not use its operation ID. The journal synchronizes the call before the runtime sends it.
A repeated operation ID returns the stored outcome; different arguments fail. An interrupted call returns `unknown`.

For another execution host, the Mac attaches `role: source` with `server: { "type": "connector", "name", "tools" }`
and the remote `sessionId`. The host attaches `role: destination` with the same `name` and `connector`.
The approval of a forwarded call comes from the Mac runtime with the remote session ID. `readOnly: true` refuses changes.

`connector.call` records contain vendor, connector, tool, arguments, result, and call ID.
Actions inside the connector service of the vendor are not attested.

## Local content

`agentCapabilities._meta["verdictan.dev/runtime"].localContent` advertises session marks.
`localContentTexts` advertises marks for a part of a message.
A mark does not change the content of the local journal. It controls only Verdictan History.

The runtime marks a session before the first connector call of that session reaches the bridge journal.
The mark also covers the parent sessions, forks, child agents, project Memory extraction, and the gateway records of the session.
Each `_verdictan/connectors/call` operation is marked.
A native stream record of the call request can precede the mark. It holds the arguments that the agent wrote, not connector content.
A client marks a whole session with `_meta["verdictan.dev/localContent"]: true` on session setup, fork, or prompt.
The same entry on `_verdictan/journal/record` marks that record, and its session when it names one.

From the mark on, each record of the session has `localContent: true`.
History receives it without payload: kind, time, scope, size, digest, operation, tool name, and correlation IDs.
The delivered record has `localContent: true`, and its capture scope says that it is not complete.
A gateway record with an unknown session stays local when the host has a marked session.

`_meta["verdictan.dev/localContent"]: { "texts": [...] }` marks only those texts, for example remembered facts.
History then receives the records with each exact text, in its JSON encodings, replaced by `[local content]`.
Byte streams, native frames, process streams, and message chunks of that session are delivered without payload,
because a stream can split a text. Other structured records keep their remaining content.
A text that an agent writes in other words is not found. Use `true` when the whole session must stay local.
On `_verdictan/journal/record`, a text mark covers only that record.

`{ "tools": ["server/tool", ...] }` names MCP tools, and can stand beside `texts`. `localContentTools` advertises it.
Set it on session setup. The request record of a call precedes a mark that the tool handler makes.
Each record of a call of a named tool is delivered without payload: approvals, updates, and bridge messages.
Messages of that server without a method are results, and are delivered without payload.
Native frames, model traffic, and raw MCP streams of the session are also delivered without payload,
because they carry calls in parts or with the conversation. Other records keep their content.
The rule does not find the same text elsewhere, for example in an agent message. Name it in `texts` too.
For a forwarded server, set the same `_meta` on `_verdictan/mcp/attach` of each side.

## Recorded command networking

`agentCapabilities._meta["verdictan.dev/runtime"].networkAccess` advertises recorded outbound command access.
A client sets `_meta["verdictan.dev/network"]` to `"outbound"` or `"none"` when opening a session.
The default is `"none"`. Kalkidan supplies `"outbound"` without a user question or setting.
The grant persists on resume and fork. Owned child agents inherit it.
A resume or fork cannot change the stored grant.
A runtime without this capability rejects an outbound session before starting it.

Each owned command receives its own HTTP CONNECT and SOCKS5 egress proxy.
`HTTP_PROXY`, `HTTPS_PROXY`, and `ALL_PROXY`, including lowercase forms, select that proxy.
The runtime replaces proxy environment values after applying command environment values.
The native agent receives neither this proxy port nor an outbound grant.
Its inference route remains the local gateway, with `mandatoryRouting: true`.
Commands retain isolation; direct external sockets and direct gateway routes remain unavailable.
Without an outbound grant, owned commands receive no outbound routes.
With the grant, their outbound route is the recording proxy. Native inference keeps its separate gateway route.
Proxy-unaware tools must use their proxy options or a proxy-aware transport.

Egress records include session, run, action, command, destination, resolved address, timestamps, byte counts, and outcomes.
Plain HTTP captures preserve headers and complete request and response bodies.
Tunnels preserve complete wire bytes and visible TLS handshake metadata without intercepting TLS.
SNI is recorded when visible. Encrypted ClientHello can conceal it.
TLS 1.2 certificate messages can expose the chain. TLS 1.3 encrypts these messages.
Encrypted or resumed handshakes report `tls.certificate_unavailable`; the proxy does not claim the chain was observed.
A separate probe would not establish the certificate used by the command.
Failed commands with observed proxy denial report `reason: "network_denied"` in the structured result.

## Client journal and processes

`_verdictan/journal/record` accepts `operationId`, `sessionId` or `projectId`, `kind`, `actor`, `inputs`, `outcome`, and `time`.
The actor is `"person"` or `"kalkidan"`. Time is supplied as a string by the client.
The journal synchronizes the record before replying. Operation IDs are unique within the local account.
A repeated operation ID returns its original stored record without executing an action.
Session correlations require an owned session; project records can precede a conversation.
Use this method for answers, approvals, Use It, Undo Changes, Stop, Resume, saves, calendar changes, and reminder changes.

`_verdictan/session/execute` accepts an owned active `sessionId` and a `process` object.
The object supports `argv`, `cwd`, `environment`, `stdin`, `background`, and a declared `previewPort`.
It runs through the same executor, workspace rules, isolation, output capture, snapshots, and egress grant as agent commands.
Set `background: true` for a preview server. The returned action identifies its task and output records.
`previewPorts` maps each declared `port` to a random loopback `hostPort` on Linux and macOS.
Clients use the host port, with SSH forwarding when necessary.
The bridge connects to `127.0.0.1`, and to `::1` when `127.0.0.1` refuses.
The bridge records each connection and both complete byte streams before forwarding.
The client method and owned `execute` tool accept a `previewPort` declaration. Both use the same captured bridge.
Use `_verdictan/session/process_status`, `process_wait`, `process_stop`, and `process_output` for client process control.
Each takes `sessionId` and `actionId`. Output also takes `stream`, with optional byte `offset` and `limit`.
Control requests remain available while a foreground command runs.
The existing task methods also list and stop background commands. The journal retains full output.
An accepted background task does not establish application readiness.
Windows preview declarations are unavailable.

## Command sessions

`agentCapabilities._meta["verdictan.dev/runtime"].commandSessions` advertises command sessions on macOS and Linux.
A command session runs client commands in one folder. It has no agent process, no model, and no prompt.
`_verdictan/commands/open` accepts `cwd`, and optional `worktrees` and `projectId`.
Its `_meta` accepts `verdictan.dev/network`, `verdictan.dev/excludedPaths`, and `verdictan.dev/localContent`.
It returns `sessionId`, the canonical `cwd` and `worktrees`, `network`, and `git`.
Use that ID with `_verdictan/session/execute`, `process_status`, `process_wait`, `process_stop`, and `process_output`.
Isolation, the network grant, previews, and the journal are the same as for agent commands.
`_verdictan/session/command` reports the state of background commands.
`_verdictan/commands/close` stops the commands and releases the session. The end of the connection also closes it.
The session is not listed, and it cannot load, resume, fork, rewind, or take a prompt.
Its journal stays readable with `_verdictan/session/actions`, and `_verdictan/journal/record` accepts its ID.

Commands of one command session run in parallel, at most 32 foreground commands.
They do not wait for commands of an agent session, and they hold no workspace lease.
Do not run a write command during a rewind of the same folder.

`process.access` is `"write"` by default. `"read"` makes the workspace read-only through isolation.
A read command takes no workspace snapshots, because it cannot change the workspace.
The journal records `snapshot_not_needed`. Use it for Git reads, with `GIT_OPTIONAL_LOCKS=0`.
A write command observes the workspace before and after. After the first command, the cost follows the changes.

`worktrees` names Git worktrees of `cwd` that are outside it. Only the client names them.
The runtime grants a worktree when its `.git` file and the repository of `cwd` name each other.
It also grants an empty folder, and makes a missing one, so that `git worktree add` can fill it.
Other paths fail with `reason: "worktree_invalid"`. Open `cwd` as the main worktree.
A folder that is replaced by a link after the grant stops later commands with `reason: "root_replaced"`.

Commands read a copy of a safe part of the global Git configuration of the person through `GIT_CONFIG_GLOBAL`.
The copy has names, formats, and defaults, and the global ignore and attribute files.
It has no credentials, helpers, aliases, remote headers, hooks, filters, or signing keys. Commands cannot change it.
Commit signing is unavailable: keys and agents stay outside the isolation. `git.signing` is `"unavailable"`.
`git.signingRequested` says that the person's configuration asks for signatures, so the client can tell the person.
Remote Git operations that need stored credentials fail for the same reason.

## Tool folders

`agentCapabilities._meta["verdictan.dev/runtime"].toolRoots` advertises tool folders on macOS and Linux.
`_meta["verdictan.dev/toolRoots"]` on session setup and on `_verdictan/commands/open` names at most 32 folders.
Commands and stdio MCP servers of the session can read and run their files, and cannot change them.
Only the client names them. They stay on resume, fork, and in owned child agents, until the client sends another list.
The journal records `tool_roots_granted` with the canonical paths, and the session result reports them.
`<folder>/bin`, or the folder itself without one, comes first in `PATH` and in the search for a program name.
A `PATH` in the command environment replaces that value.
A link that points into a named folder works. A folder that is replaced by a link stops later commands.
The runtime refuses a folder with `reason: "tool_root_invalid"` in these cases:
the home folder or a folder above it, a folder above a workspace, a private folder of the home folder
(for example `.ssh`, `.config`, `.claude`, `Documents`, `Library/Keychains`), or a folder with a credential file.
Name the folder of one tool version, for example `~/.local/share/fnm/node-versions/<version>/installation`.

## Execution-host journal transfer

`_verdictan/journal/read` reads every ACP profile and gateway action journal on the local execution host.
It includes session records, forwarded MCP records, egress, client actions, process boundaries, previews, and imported host records.
The response includes `hostId`, ordered `records`, `cursor`, `hasMore`, and journal writer state.
Each record also carries its source `hostId`. Import preserves that per-record identity.
Pass the returned cursor after reconnecting. No event-kind filter excludes records.
All ACP and gateway writers share one host journal lock and durable position counter. Cursor order follows journal commit order.
Each producer registers its canonical journal location durably before acknowledging its first record.
Host reads and History delivery include these registered sources, even when the reader has a different data-directory environment.
The opaque host cursor retains a position for each source.
A newly registered source includes its earlier records even when another source has advanced.
Host cursors and session-action cursors are distinct; clients pass each cursor back to its owning method unchanged.
Timestamps retain their original observation times, which can differ from cursor order.

The Mac reads each SSH execution host and submits its pages through `_verdictan/journal/import`.
Import accepts `hostId` and complete `records`, preserves their original content, and writes durable local wrappers.
Each wrapper has `kind: "host_record"`; `inputs` contains the original record and `outcome.hostId` identifies its host.
Repeated host/cursor pairs return their stored wrapper. The client advances its remote cursor only after import succeeds.
The Mac remains the owner of the consolidated records.

## Process observation limits

`internalOsActionsAttested` remains `false` on each platform.
The executor captures its owned process start, arguments, PID, input, output, and exit.
It does not claim to observe every descendant exec or intermediate operating-system action.
Owned Linux commands use an unprivileged ptrace supervisor for descendant process observation.
The supervisor attaches before command execution and records starts, exec paths, exact arguments, parent IDs, and exits.
It resumes traced processes only after the journal acknowledges their events durably.
A command cannot execute if isolation or observation setup fails.
The command result and process-status response include `processObservation`.
`descendantProcessesAttested` becomes true only after the subtree exits and the completion record is acknowledged.
Observation failure stops the command and leaves attestation false.
This does not attest every syscall or intermediate filesystem operation.
macOS Endpoint Security descendant observation requires an Apple entitlement absent from this CLI.
Capture coverage names these limits explicitly.
Linux supports persistent path exclusions through empty read-only file and directory mounts.
Windows filesystem exclusions remain unavailable.

## Signed-in journal delivery

CLI sign-in enrolls the installation through `POST /v1/history/installations/{installation_id}/gateway`.
Active organization members can enroll their own installation without general gateway-administration permission.
The returned machine token can write only the owning user's journal History sessions and entries.
It grants no provider, relay, recall, or general gateway-runtime access.
The runtime stores the token privately and renews expired or rejected tokens.
Tokens bind to individual active account sessions, so separate sign-ins do not revoke each other.
Admission checks current account-session expiry, revocation, and active organization membership.
Delivery uses the returned regional API origin.
During `acp serve`, the journal worker delivers every record, including the pre-sign-in backlog and imported host records.
It uses durable outbox state, per-session acknowledged cursors, and deterministic `delivery_id` values.
Session and delivery identities include the authenticated user and original execution host, independently of the uploading gateway.
Retries do not create additional History entries.
A delivery advances its local checkpoint only after an acknowledgment identifies the expected delivery and session entry.
Interrupted chunk retries can acknowledge an already-stored delivery without recreating the entry.
Remote imports retain the origin host identity for the same delivery identity as direct uploads.

`_verdictan/history/connect` accepts a native sign-in handoff over the private ACP transport.
The fields are `apiUrl`, `apiToken`, `orgId`, and optional `userId`, `expiresAt`, and `clientVersion`.
Kalkidan supplies its actual application version for desktop-token enrollment.
The runtime can obtain it from ACP `initialize.clientInfo.version` or `--desktop-version`.
The account credential is stored privately and is never forwarded to the native agent or command environment.
Account lifecycle records omit bearer credentials from the session transcript.
An empty connect request uses the stored CLI profile credentials.
`_verdictan/history/disconnect` disables delivery and removes the native account binding.
CLI sign-out disables delivery and cancels active uploads when observed by the worker.
Local journals remain available. Local gateway inference does not depend on this connection.
Signing in again enables delivery and continues the backlog.

Records larger than the upload threshold use `journal_chunk` on the existing machine History entry route.
Chunks include a complete-record digest, index, count, and exact base64 bytes.
The API stages incomplete deliveries for 24 hours and assembles the complete entry after all chunks arrive.
The existing retention worker removes expired staged chunks.
The complete entry passes through the ordinary organization-scoped, idempotent History writer.
Deploy `api/migrations/0090_history_journal_chunks.sql` with the API changes before releasing this CLI behavior.

Journal deliveries request 2555-day retention. Shorter effective organization retention remains authoritative.
The API accepts 1 to 2555 days. Local journal records do not expire automatically.
Organizations with mandatory History payload redaction reject these entries with `history.journal_full_capture_unavailable`.
The worker keeps pending local deliveries and reports that full capture is unavailable under that policy.

Codex executor approvals use `session/request_permission`.
When the native protocol omits a tool-call identifier, the request uses a separate approval ID and includes pending calls as candidates.
`verdictan.dev/toolCallCorrelation` reports `unavailable`; the runtime does not attach the request to an arbitrary pending command.
Workspace roots remain explicit on every executor approval.
Claude executor approvals carry the same `verdictan.dev/workspaceRoots` entry.
