# ACP v1 protocol ownership

Pinned wire schema: `src/acp/schema/schema.json`, upstream schema-v1.26.0.
Method metadata: `src/acp/schema/meta.json`. Upstream license: `src/acp/schema/LICENSE`.
This inventory describes implementation paths, not test or compatibility results.

## Connection methods

`transport.ts` owns UTF-8 framing, concurrent requests, IDs, errors, notifications, and request cancellation.
`server.ts` owns initialization, authentication gates, logout, and dispatch.
`schema.ts` applies the pinned request, response, and update schemas.
The runtime has no account traffic. `local-execution.ts` owns the local account identity.

## Session methods

`server.ts` and `history.ts` own new, load, resume, list, close, and delete.
They own account scope, writer leases, pagination, tombstones, history replay, and workspace roots.
`backends/native.ts` and `backends/relay.ts` own backend restoration and deletion.
`managed-launch.ts` retains separate ACP, native, runtime, and turn identifiers.

`session/prompt` serializes active turns and preserves ordered content.
`session/cancel` cancels active work without creating a replacement prompt.
`session/set_mode` and `session/set_config_option` use native or relayed configuration.
Native changes during active work apply on the next turn.
Boolean configuration requires the client's boolean capability.

## Content and updates

Native Codex and Claude accept text, resource links, and images.
They do not advertise direct audio or embedded resource content.
The relay accepts those optional forms only when the child advertises them.
No path silently transcribes audio or selects another model.

Native adapters map agent text, thoughts, tool calls, tool updates, plans, and completion.
Completed text is emitted when no streaming text was received for that message.
Codex maps native plan and context-compaction events.
Claude maps dynamic commands, notices, compaction boundaries, and context usage.
The relay preserves standard updates, including resource content, tool diffs, locations,
configuration groups, commands, usage, compaction summaries, and session information.

`server.ts` gates notices and compaction on client capabilities.
`client-operations.ts` gates client callbacks and applies callback schemas.
Unknown categories remain opaque presentation data.
Optional features are not invented when a native backend lacks an event or operation.

## Client methods

The relay supports filesystem reads and writes, terminal create/output/wait/kill/release,
permission requests, and form or URL elicitation through `client-operations.ts`.
The complete client path must advertise the respective capability.
Native adapters use their own managed tools instead of moving tool execution into desktop callbacks.

`interactions.ts` translates native approvals and questions.
Permission replies retain the selected option ID. Cancellation is not approval.
Request-scoped elicitation maps through independent client and child request IDs.
URL completion notifications retain their elicitation correlation.

## MCP and extensions

`configuration.ts` resolves native configuration scopes and executable commands.
`mcp-configuration.ts` merges definitions and translates native MCP configuration.
`acp-mcp-bridge.ts` supplies HTTP and SSE access to isolated backends.
`acp-mcp-stdio.ts` owns stdio process trees.
`acp-mcp-forwarding.ts` implements source/destination attach, detach, reconnect, close, and frames.

`acp-runtime.md` defines discovery, configuration, evidence, history, forwarding, and steering extensions.
External opaque extensions require negotiation on both ends.
Stable v1 does not imply draft v2, session-fork support, or external-editor onboarding.

## Backend protocol revisions

Codex uses app-server v2 methods behind the outward ACP v1 connection.
The source contract is commit `d7de4dd3ac3e4c489368c3985013e78622496962` in `openai/codex`.
Definitions are under `codex-rs/app-server-protocol/src/protocol/v2/`.
Its adapter minimum is recorded in `src/acp/agent-version.ts`.
Claude uses its stream-json control protocol and the minimum in that same file.
Its declaration reference is `@anthropic-ai/claude-agent-sdk` version `0.3.220`.
The published artifact SHA-1 is `c59cf4fff0166d2a04b01470eabdd4a792add48d`.
These pins identify adapter source references, not executed compatibility checks.
OpenCode uses its documented `acp` invocation and OpenAI Responses provider configuration.
The managed configuration selects its built-in OpenAI provider and restricts the model list.
It does not install a custom provider package during launch.
Backend versions and optional features remain discovery facts, separate from the ACP protocol version.
