# Managed ACP runtime contract

Contract major: 1. Protocol: ACP v1, schema-v1.26.0.
The account capability `acp.runtime.v1` identifies this runtime interface.
CLI and desktop version numbers do not need to match.
This contract describes source behavior. It is not a release qualification report.

## Commands and transport

```text
verdictan acp agents list --json
verdictan acp agents inspect --agent codex --json
verdictan acp serve --agent codex --profile kalkidan --desktop-version VERSION
```

Use `--agent-config PATH` to select a configuration file.
The default is `~/.verdictan/acp/PROFILE/agents.json`.
Session records, host identity, and release journals stay under the profile directory.
An alternate configuration path does not change that identity directory.

The server exchanges newline-delimited JSON-RPC on stdin and stdout.
Stdout contains protocol messages only. Diagnostics use stderr.
Numeric and string request IDs remain distinct. Notifications have no responses.
Initialize each connection before other operations. The negotiated protocol version is 1.

The account supervisor retains account credentials.
Local CLI processes use its private authenticated socket or named pipe.
Kalkidan uses `--account-bridge` with inherited descriptors 3 and 4.
Descriptor 3 receives account responses. Descriptor 4 sends account requests.
These private frames never appear in ACP streams.
SSH account operations use the existing authenticated desktop connection.
Neither ACP nor SSH receives the desktop account refresh token.

Account logout stops owned runs and revokes managed runtimes.
It does not log out native subscription accounts or unrelated Verdictan profiles.
Provider terminal authentication uses the selected CLI profile with `--login-only`.
The desktop must advertise terminal authentication only when it provides that workflow.

## Discovery and configuration

The built-in profile IDs are `codex`, `claude`, and `opencode`.
Treat profile IDs as opaque. User configuration can add external ACP profiles.
The catalog uses native app-server, native stream-json, and `opencode acp`, respectively.
Executable resolution occurs on the execution host, including login-shell paths.
Windows npm wrappers resolve to their Node executable and script.

`_verdictan/agents/list` returns configured candidates and cached installation facts without probing.
Unknown account, platform, and protocol readiness requires inspection before execution.
`_verdictan/agents/inspect` also initializes external ACP profiles without submitting a prompt.
Both return `schemaVersion`, `protocolVersion`, `cliVersion`, and `agents`.
Codex uses its host model cache. When that cache is absent, inspection reads the installed app-server model catalog in an isolated temporary workspace. It creates no thread or model turn.
API selections use the account model catalog; subscription selections use native catalogs.
Command JSON uses `schema_version`, `protocol_version`, `cli_version`, and `execution_host`.

Each agent record separates installation, protocol, authentication, routing, platform, and features.
`selections` contains model IDs, access modes, provider connections, and readiness.
Only ready selections can start managed work. Optional audio does not gate text.
An ACP handshake does not establish model-routing compatibility.
External routing supports `opencode-openai-responses` and explicit `openai-responses-env` mappings.
External profiles currently use API access. Native subscription access is not silently converted to API billing.

`_verdictan/config/get` returns definitions without secret environment values.
`_verdictan/config/set` accepts `agents` and applies changes to new connections.
Omitting an existing environment preserves its stored values.
`_verdictan/config/import` imports legacy executable preferences and host identity once.
Existing CLI settings take precedence. Reopen the connection after a successful import.

## Sessions and managed selection

Use standard session methods for creation, load, resume, listing, deletion, and close.
Load replays saved updates. Resume restores without replay.
Close releases active execution but preserves history. Delete removes backend state and tombstones history.
One OS-backed lease owns each writable session across processes.
An ACP session can contain several native process-per-turn runs.
Native history predating ACP remains read-only in Kalkidan.

Session setup accepts these `_meta` entries:

- `verdictan.dev/selection`: explicit managed selection with snake_case account fields.
- `verdictan.dev/choices`: saved desktop choices resolved by the CLI.
- `verdictan.dev/model`: selected model ID.
- `verdictan.dev/access`: selected `model`, `provider_access_mode`, and optional `provider_connection_id`.
- `verdictan.dev/executionHost`: desktop host reference.
- `verdictan.dev/scope`: `project_id` and `task_id` attribution.
- `verdictan.dev/memory`: managed project Memory configuration.

`_verdictan/agents/provision` provisions the selected computer resource through the account supervisor.
`_verdictan/session/list` lists owned sessions across profiles, with opaque pagination cursors.
`_verdictan/session/transcript` returns saved updates, profile, roots, title, and timestamps.
`_verdictan/session/evidence` returns binding, execution, evidence, policies, and governance presentation.
All session extensions require `sessionId` and the owning account.

Ordinary prompts run serially. The desktop owns drafts and queued submissions.
`_verdictan/session/steer` accepts `sessionId` and `prompt` for supported active native turns.
Steering never cancels and resubmits a prompt as a substitute.
Native configuration changes during a turn apply to the next turn.
Responses identify this timing in `verdictan.dev/application` metadata.
Session results and native configuration updates include `verdictan.dev/session` metadata.
It reports model-specific `promptCapabilities` and effective `mcpConfiguration` names, transports, origins, scopes, and execution hosts.
These summaries exclude server credentials and environment values.
External model changes cannot escape the managed model selection.
Native subagent presentation uses `verdictan.dev/subagents` metadata on tool updates.
Child text identifies its parent with `verdictan.dev/parentToolCallId`.
Kalkidan owns queued drafts on the execution host and pauses them after interruption or failure.
Queue controls are desktop operations, not ACP protocol methods.

## MCP forwarding

Session setup accepts stdio, HTTP, and SSE MCP definitions according to capabilities.
Native configuration scopes are merged with explicit session definitions.
OpenCode JSON and JSONC MCP settings retain user, custom, project, inline, managed-file, and macOS MDM precedence.
Environment and file references resolve on the execution host.
Organization defaults available only through a provider login remain owned by OpenCode.
Explicit ACP definitions can supply servers unavailable to the managed profile.
See [OpenCode configuration](https://opencode.ai/docs/config/) and [MCP configuration](https://opencode.ai/docs/mcp-servers/).
Runtime credential headers remain on their execution host.

Forwarding uses the existing SSH connection to copy opaque MCP JSON-RPC frames:

1. Request `_verdictan/mcp/attach` on the desktop CLI with `role: source`, `server`, and `cwd`.
2. Request the same method on the execution CLI with `role: destination`, `name`, and `scope`.
3. Map each returned `bindingId` to its peer binding.
4. Forward `_verdictan/mcp/message` notifications as `_verdictan/mcp/frame` notifications to the peer.
5. Include the destination's returned `server` in session setup.
6. Detach both bindings when their desktop connection is lost.
7. Close both bindings when their last owning client releases them.

`_verdictan/mcp/detach` closes transport resources but retains reconnect configuration.
`_verdictan/mcp/reconnect` creates fresh transport resources for the retained binding ID.
It never replays pending tool calls. Reattach the returned definition during session setup.
`_verdictan/mcp/close` releases the binding and retained configuration.
`_verdictan/mcp/status` reports connection loss with `replayed: false`.
Destination endpoints are private loopback bridges, not public MCP services.

MCP forwarding does not grant independent model-routing authorization.
Model-calling tools need their own configured managed endpoint.
Verdictan cannot attest model calls made inside a third-party remote MCP service.

## Evidence and lifecycle

`_verdictan/evidence` carries independent evidence updates and a presentation projection.
`_verdictan/policy` carries gateway policy records.
These extensions are distinct from standard ACP usage updates.
Subscription usage retains token accounting without invented API charges.
Missing evidence remains unavailable rather than becoming a successful policy result.

Transport loss cancels directly attached work. A retained SSH host connection may continue its run.
Credentials expire according to their issued deadline. An open ACP connection does not renew them.
Cleanup owns the child tree, gateway, MCP bridges, and runtime revocation.
Failed revocations remain in an account-scoped journal for later retry.
OS locks prevent recovery from revoking another live CLI process's runtime.

Errors use JSON-RPC error codes plus actionable `data.reason` where available.
Authentication, missing installation, unsupported version, routing configuration, binding mismatch,
policy rejection, and process failure remain distinct conditions.

## Platform baseline

macOS x64 and ARM64 require macOS 13.5, the Node 24 baseline, and `sandbox-exec`.
Linux x64 and ARM64 require kernel 4.18, glibc 2.28, Bubblewrap, Python 3, and user namespaces.
Linux account storage also requires the existing secure-store integration.
Windows x64 and ARM64 use bundled MXC 1.0.1 and its native assets.
Supported Windows baselines include builds 26100.9550, 26200.9550, and 28000.2804.
Windows packages remain unsigned. No signing credentials are required.
Discovery reports missing prerequisites independently of executable installation.
Desktop minimums must also satisfy its selected Electron version.

## Desktop combination

Kalkidan uses Electron 44. Its macOS 13 baseline is lower than the CLI Node 24 baseline, so both macOS architectures require 13.5.
Windows x64 and ARM64 require the MXC Windows builds listed above; that requirement exceeds Electron’s Windows baseline.
Linux desktop installations must also use a distribution supported by Electron and Chromium, such as Ubuntu 22.04 or Debian 12, with the native desktop libraries.
Headless SSH hosts do not run Electron and use the CLI Linux baseline above.
See [Electron 44](https://www.electronjs.org/blog/electron-44-0) and [Electron platform support](https://github.com/electron/electron/blob/main/README.md#platform-support).

The machine-readable file includes extension request/result definitions under `x-verdictan-methods`, notification payloads under `x-verdictan-notifications`, and reusable metadata in `$defs`.

## Deletion and retained evidence

Deleting a managed chat removes its transcript and backend restoration data.
The tombstone retains execution attribution, policy records, evidence, and pending release information.
`_verdictan/session/evidence` remains available to the owning account for that deleted session.
Deleted sessions remain absent from listings and cannot load or resume.
